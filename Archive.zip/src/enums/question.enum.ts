export enum QuestionType {
  SINGLE = 'single',
  MULTIPLE = 'multiple',
}
